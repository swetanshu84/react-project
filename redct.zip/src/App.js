import React, { Component } from 'react';
import Contactus from './contact';

class App extends Component {
  render() {
    return (
      <Contactus />
    );
  }
}

export default App;
