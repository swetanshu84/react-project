import React, { Component } from 'react';
import _ from 'lodash';
//import classNames from 'classnames';

class Contactus extends Component {
  constructor(props){
    super(props);
    this.state = {
      form:{
        name:'',
        email:'',
        phone:'',
        message:''
      },
      errors:{
        name:null,
        email:null,
        phone:null,
        message:null
      }
    };
    this._onTextChange = this._onTextChange.bind(this);
    this._onFormSubmit = this._onFormSubmit.bind(this);
    this._formValidation = this._formValidation.bind(this);
  }
  _isEmail(emailAddress) {

        const emailRegex = /^(([^<>()\[\].,;:\s@"]+(\.[^<>()\[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,})$/i;

        return emailRegex.test(emailAddress);
    }

  _isPhone(phone) {

      const phoneRegex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;

      return phoneRegex.test(phone);
  }
  _formValidation(fields = [],callback){
    let {form,errors} = this.state;
    const validations = {
      name:[
        {
          errorMessage:'Name is required',
          isValid:() =>{
            return form.name.length;
          }
        }
      ],
      email:[
        {
          errorMessage:'Email is required',
          isValid:() =>{
            return form.email.length;
          }
        },
        {
          errorMessage:'Email is not valid!',
          isValid:() =>{
            return this._isEmail(form.email);
          }
        }
      ],
      phone:[
        {
          errorMessage:'Phone is required',
          isValid:() =>{
            return form.phone.length;
          }
        },
        {
          errorMessage:'Phone is not valid!',
          isValid:() =>{
            return this._isPhone(form.phone);
          }
        }
      ],
      message:[
        {
          errorMessage:'Message is required',
          isValid:() =>{
            return form.message.length;
          }
        }
      ],
    }
    _.each(fields,(field) => {

      let fieldValidations = _.get(validations,field,[]);
      errors[field] = null;

      _.each(fieldValidations,(fieldValidation) =>{
          const isValid = fieldValidation.isValid();
          if(!isValid){
            return errors[field] = fieldValidation.errorMessage;
          }
      });
      console.log(errors);
    });

    this.setState({
          errors: errors
      }, () => {

          let isValid = true;

          _.each(errors, (err) => {

              if (err !== null) {
                  isValid = false;
              }
          });
          return callback(isValid);

      });
  }

  _onFormSubmit(event){
    event.preventDefault();
    this._formValidation(['name','email','phone','message'],(isValid)=>{
      //console.log("The form is valid ?",isValid);
      if(!isValid){
        window.document.getElementById('errorDv').innerHTML = "<p class='alert alert-danger'> All * fields are required!</p>";
      }else{

        window.document.getElementById('errorDv').style.display = "<p class='alert alert-success'>Your contact request successfully sent!</p>";
      }
    });

  }
  _onTextChange(event){
    let {form} = this.state;
    const fieldName = event.target.name;
    const fieldValue = event.target.value;
    form[fieldName] = fieldValue;
    this.setState({form:form});
  }
  render() {
    const {form,errors} = this.state;
    return (

      <div className={"Contactus"}>
        <section id="contact">
          <div className={"container"}>
            <div className={"row"}>
              <div className="col-lg-12 text-center">
                <h2 className={"section-heading text-uppercase"}>Contact Us</h2>
                <h3 className={"section-subheading text-muted"}>Lorem ipsum dolor sit amet consectetur.</h3>
              </div>
            </div>
            <div className={"row"}>
              <div className={"col-lg-12"}>
              <div id={'errorDv'}></div>
                <form  name={"sentMessage"} noValidate onSubmit={this._onFormSubmit}>
                  <div className={"row"}>
                    <div className={"col-md-6"}>
                      <div className={"form-group"}>
                        <input onChange={this._onTextChange} className={"form-control"} id={"name"}  name={"name"} type={"text"} placeholder={"Your Name *"} required data-validation-required-message={"Please enter your name."} />
                        <p className={"help-block text-danger"}></p>
                      </div>
                      <div className={"form-group"}>
                        <input onChange={this._onTextChange}  className={"form-control"}  id={"email"}  name={"email"} type={"email"} placeholder={"Your Email *"} required data-validation-required-message={"Please enter your email address."} />
                        <p className={"help-block text-danger"}></p>
                      </div>
                      <div className={"form-group"}>
                        <input onChange={this._onTextChange}  className={"form-control"}  id={"phone"}  name={"phone"} type={"tel"} placeholder={"Your Phone *"} required data-validation-required-message={"Please enter your phone number."} />
                        <p className={"help-block text-danger"}></p>
                      </div>
                    </div>
                    <div className={"col-md-6"}>
                      <div className={"form-group"}>
                        <textarea onChange={this._onTextChange}  className={"form-control"} id={"message"}  name={"message"} placeholder={"Your Message *"} required data-validation-required-message={"Please enter a message."}></textarea>
                        <p className={"help-block text-danger"}></p>
                      </div>
                    </div>
                    <div className="clearfix"></div>
                    <div className={"col-lg-12 text-center"}>
                      <div id="success"></div>
                      <button  className={"btn btn-primary btn-xl text-uppercase"} type={"submit"}>Send Message</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }
}

export default Contactus;
